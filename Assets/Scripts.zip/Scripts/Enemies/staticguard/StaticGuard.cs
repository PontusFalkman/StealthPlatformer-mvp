﻿using UnityEngine;
using Project.Player.Stealth;
using Project.Enemies.Shared.Perception;

namespace Project.Enemies.StaticGuard
{
    public class StaticGuard : MonoBehaviour
    {
        [Header("Refs")]
        public Transform player;                  // assign at runtime or in scene
        public LayerMask losMask = ~0;            // walls, obstacles
        public Transform facing;                  // use a child pointing “right”; if null uses transform.right

        [Header("Tuning")]
        public PerceptionTuning tuning = PerceptionTuning.Normal;

        [Header("State (read-only)")]
        public bool alerted;
        public bool spotted;
        public float alertTimer;
        public float lastRate; // debug
        public float lastProb; // debug
        [SerializeField] SpriteRenderer facingSprite;  // drag the Facing child’s SpriteRenderer here

        IPlayerStealthSignals signals;

        void Awake()
        {
            if (!player) player = GameObject.FindGameObjectWithTag("Player")?.transform;
            signals = player ? player.GetComponent<IPlayerStealthSignals>() : null;
        }

        void Update()
        {
            if (spotted || signals == null || player == null) return;

            Vector2 guardPos = transform.position;
            Vector2 playerPos = signals.WorldPosition;
            Vector2 toPlayer = (playerPos - guardPos);
            float dist = toPlayer.magnitude;

            // LOS
            bool los = !Physics2D.Linecast(guardPos, playerPos, losMask);

            // Instant-spot rule
            if (los && dist <= tuning.hardProx && (signals.Visibility >= 1f || signals.Noise >= 1f))
            { Spot(); return; }

            // FOV (static facing)
            Vector2 forward = facing ? (Vector2)facing.right : (Vector2)transform.right;
            bool inFov = los && PerceptionMath.InFOV(forward, toPlayer, tuning.fovDeg);

            // Signals
            float V = Mathf.Clamp01(signals.Visibility) * (inFov ? 1f : 0f);
            float N = Mathf.Clamp01(signals.Noise);

            float visFall = PerceptionMath.VisFalloff(dist, tuning.visRange);
            float sndFall = PerceptionMath.SndFalloff(dist, tuning.sndRef);

            float rate = tuning.kv * V * visFall + tuning.kn * N * sndFall;
            float p = PerceptionMath.TickProb(rate, Time.deltaTime);

            lastRate = rate; lastProb = p;

            // Single RNG draw
            if (Random.value < p)
            {
                if (!alerted) { alerted = true; alertTimer = 0f; OnAlertEnter(); }
                else { Spot(); return; } // second success while alerted
            }

            // Confirmation timer
            if (alerted)
            {
                alertTimer += Time.deltaTime;
                if (alertTimer >= tuning.confirmTime && los) { Spot(); return; }

                // Lose LOS during alert → drift back to idle
                if (!los) alertTimer = Mathf.Max(0f, alertTimer - Time.deltaTime);
                if (alertTimer <= 0.05f && !los) { alerted = false; OnAlertExit(); }
            }
        }

        void Spot()
        {
            spotted = true;
            OnSpotted();
        }

        // Hooks
        void OnAlertEnter()
        {
            if (facingSprite) facingSprite.color = Color.yellow;
            Debug.Log($"{name}: ALERTED (player noticed, timer started)");
        }

        void OnAlertExit()
        {
            if (facingSprite) facingSprite.color = Color.white;
            Debug.Log($"{name}: CALMED DOWN (lost sight of player)");
        }

        void OnSpotted()
        {
            if (facingSprite) facingSprite.color = Color.red;
            Debug.Log($"{name}: SPOTTED PLAYER (full detection)");
        }

#if UNITY_EDITOR
        void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, tuning.visRange);
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, tuning.hardProx);

            // FOV gizmo
            Vector3 origin = transform.position;
            Vector2 forward = (GetComponentInChildren<Transform>() ? (Vector2)(GetComponentInChildren<Transform>().right) : (Vector2)transform.right);
            float half = tuning.fovDeg * 0.5f * Mathf.Deg2Rad;
            Vector2 left = new Vector2(Mathf.Cos(half), Mathf.Sin(half));
            Vector2 right = new Vector2(Mathf.Cos(half), -Mathf.Sin(half));
            var rot = Quaternion.FromToRotation(Vector2.right, forward);
            Gizmos.color = Color.red;
            Gizmos.DrawLine(origin, origin + (Vector3)(rot * (left * tuning.visRange)));
            Gizmos.DrawLine(origin, origin + (Vector3)(rot * (right * tuning.visRange)));
        }
#endif
    }

}
