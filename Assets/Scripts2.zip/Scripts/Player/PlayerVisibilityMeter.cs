using System;
using UnityEngine;

public class PlayerVisibilityMeter : MonoBehaviour
{
    [Header("Settings")]
    public VisibilitySettings settings;   // ambientDarkness [0..1], smoothing > 0, sampleRadius

    public float CurrentValue => _current; // 0 hidden .. 1 visible
    public event Action<float> OnChanged;

    // Debug
    [SerializeField] float dbgEnv;     // averaged env visibility at position
    [SerializeField] float dbgTarget;  // clamped target after env sample
    [SerializeField] float dbgOut;     // smoothed output

    float _current;

    void OnEnable()
    {
        // Initialize from environment, not just 1 - ambient
        float env0 = SampleEnv(transform.position);
        _current = Mathf.Clamp01(env0);
        OnChanged?.Invoke(_current);
    }

    void Update()
    {
        if (!settings) return;

        Vector2 p = transform.position;

        // Environment query (center + ring samples if sampleRadius > 0)
        float env = SampleEnv(p);
        float target = Mathf.Clamp01(env);

        // Smooth
        float lambda = 1f - Mathf.Exp(-Mathf.Max(0f, settings.smoothing) * Time.deltaTime);
        float old = _current;
        _current = Mathf.Lerp(_current, target, lambda);

        // Debug
        dbgEnv = env;
        dbgTarget = target;
        dbgOut = _current;

        if (!Mathf.Approximately(old, _current))
            OnChanged?.Invoke(_current);
    }

    float SampleEnv(Vector2 p)
    {
        float ambient = settings ? settings.ambientDarkness : 0.2f;
        float r = settings ? Mathf.Max(0f, settings.sampleRadius) : 0f;

        if (r <= 0.0001f)
            return VisibilityField.SampleAt(p, ambient);

        // Center + 6 around a hex ring for stability on edges
        const int RING = 6;
        float sum = VisibilityField.SampleAt(p, ambient);

        // angles: 0, 60, 120, 180, 240, 300 degrees
        for (int i = 0; i < RING; i++)
        {
            float ang = (Mathf.PI * 2f / RING) * i;
            Vector2 o = new Vector2(Mathf.Cos(ang), Mathf.Sin(ang)) * r;
            sum += VisibilityField.SampleAt(p + o, ambient);
        }
        return sum / (RING + 1);
    }
}
