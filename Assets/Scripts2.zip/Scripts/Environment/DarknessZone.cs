using UnityEngine;
using System.Collections.Generic;

[AddComponentMenu("Stealth/Darkness Zone")]
public class DarknessZone : MonoBehaviour
{
    public static readonly List<DarknessZone> All = new();

    [Header("Shape")]
    [Min(0f)] public float innerRadius = 1f;          // full darkness inside
    [Min(0.01f)] public float falloffDistance = 3f;   // fades to 0 by inner+falloff

    [Header("Strength")]
    [Range(0f, 1f)] public float intensity = 1f;       // 1 = full dark
    public AnimationCurve falloff = AnimationCurve.EaseInOut(0, 1, 1, 0);

    [Header("Static control")]
    public bool lockToStartPosition = true;

    [Header("Stepped Falloff")]
    public bool useSteppedFalloff = true;
    [Min(1)] public int steps = 5;                    // dark: 5 steps

    Vector2 cachedOrigin;

    void OnEnable()
    {
        cachedOrigin = transform.position;
        if (!All.Contains(this)) All.Add(this);
    }
    void OnDisable() { All.Remove(this); }

    static float StepFalloff(float t, int s)
    {
        if (t <= 0f) return 1f;
        if (t >= 1f) return 0f;
        s = Mathf.Max(1, s);
        return Mathf.Ceil((1f - t) * s) / s;
    }

    public float DarknessAt(Vector2 worldPos)
    {
        Vector2 origin = lockToStartPosition ? cachedOrigin : (Vector2)transform.position;
        float d = Vector2.Distance(worldPos, origin);
        if (d <= innerRadius) return intensity;

        float outer = innerRadius + falloffDistance;
        if (d >= outer) return 0f;

        float t = Mathf.InverseLerp(innerRadius, outer, d);
        float f = useSteppedFalloff ? StepFalloff(t, steps)
                                    : Mathf.Clamp01(falloff.Evaluate(t));
        return intensity * f;
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Vector3 o = lockToStartPosition ? (Vector3)cachedOrigin : transform.position;
        Gizmos.color = new Color(0.1f, 0.1f, 0.1f, 0.3f);
        Gizmos.DrawWireSphere(o, innerRadius);
        Gizmos.DrawWireSphere(o, innerRadius + falloffDistance);
    }
#endif
}
