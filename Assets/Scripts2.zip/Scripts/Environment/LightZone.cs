﻿using UnityEngine;
using System.Collections.Generic;

[AddComponentMenu("Stealth/Light Zone")]
public class LightZone : MonoBehaviour
{
    public static readonly List<LightZone> All = new();

    [Header("Shape")]
    [Min(0f)] public float innerRadius = 1f;          // full light inside
    [Min(0.01f)] public float falloffDistance = 3f;   // fades to 0 by inner+falloff

    [Header("Strength")]
    [Range(0f, 1f)] public float intensity = 1f;       // 1 = full light
    public AnimationCurve falloff = AnimationCurve.EaseInOut(0, 1, 1, 0);

    [Header("Stepped Falloff")]
    public bool useSteppedFalloff = true;
    [Min(1)] public int steps = 3;                    // light: 3 steps

    void OnEnable() { if (!All.Contains(this)) All.Add(this); }
    void OnDisable() { All.Remove(this); }

    static float StepFalloff(float t, int s)
    {
        if (t <= 0f) return 1f;
        if (t >= 1f) return 0f;
        s = Mathf.Max(1, s);
        // 1, (s-1)/s, ..., 1/s, then 0 at edge
        return Mathf.Ceil((1f - t) * s) / s;
    }

    public float VisibilityAt(Vector2 worldPos)
    {
        Vector2 origin = transform.position; // dynamic torches
        float d = Vector2.Distance(worldPos, origin);
        if (d <= innerRadius) return intensity;

        float outer = innerRadius + falloffDistance;
        if (d >= outer) return 0f;

        float t = Mathf.InverseLerp(innerRadius, outer, d); // 0..1 toward edge
        float f = useSteppedFalloff ? StepFalloff(t, steps)
                                    : Mathf.Clamp01(falloff.Evaluate(t));
        return intensity * f;
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1f, 1f, 0.2f, 0.25f);
        Gizmos.DrawWireSphere(transform.position, innerRadius);
        Gizmos.DrawWireSphere(transform.position, innerRadius + falloffDistance);
    }
#endif
}
