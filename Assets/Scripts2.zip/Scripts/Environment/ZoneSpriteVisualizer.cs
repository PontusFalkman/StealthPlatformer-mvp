﻿using UnityEngine;

[ExecuteAlways]
[AddComponentMenu("Stealth/Debug/Zone Sprite Visualizer")]
[RequireComponent(typeof(SpriteRenderer))]
public class ZoneSpriteVisualizer : MonoBehaviour
{
    public enum Mode { Children, Shader, Gizmos }
    public Mode mode = Mode.Shader;

    [Range(0f, 1f)] public float coreAlpha = 0.9f;
    public Sprite ringSprite;                 // used in Children mode
    public Color lightColor = new(1f, 1f, 0.2f, 1f);
    public Color darkColor = new(0.1f, 0.1f, 0.1f, 1f);
    public int sortingOrder = 0;

    public LightZone lightZone;               // assign one of these
    public DarknessZone darkZone;

    // RadialFade2D shader props (Shader mode)
    static readonly int ID_Color = Shader.PropertyToID("_Color");
    static readonly int ID_CoreAlpha = Shader.PropertyToID("_CoreAlpha");
    static readonly int ID_InnerFrac = Shader.PropertyToID("_InnerFrac");
    static readonly int ID_Steps = Shader.PropertyToID("_Steps");

    SpriteRenderer sr;

    void OnEnable() { sr = GetComponent<SpriteRenderer>(); Refresh(); }
    void OnValidate() { Refresh(); }
    void Update() { if (!Application.isPlaying) Refresh(); }

    public void Refresh()
    {
        if (!lightZone && !darkZone) { ClearChildren(); if (sr) sr.enabled = false; return; }

        int steps = lightZone ? 3 : 5;
        Color baseCol = lightZone ? lightColor : darkColor;

        // *** FIX: use innerRadius + falloffDistance, not .radius ***
        float inner = lightZone ? Mathf.Max(0.0001f, lightZone.innerRadius)
                                : Mathf.Max(0.0001f, darkZone.innerRadius);
        float outer = inner + (lightZone ? Mathf.Max(0.0001f, lightZone.falloffDistance)
                                         : Mathf.Max(0.0001f, darkZone.falloffDistance));

        switch (mode)
        {
            case Mode.Children:
                BuildChildren(steps, baseCol, inner, outer);
                if (sr) sr.enabled = false;
                break;

            case Mode.Shader:
                ClearChildren();
                if (sr)
                {
                    sr.enabled = true;
                    sr.sortingOrder = sortingOrder;
                    // scale sprite so diameter = 2*outer units
                    transform.localScale = Vector3.one * (2f * outer);

                    var mpb = new MaterialPropertyBlock();
                    sr.GetPropertyBlock(mpb);
                    mpb.SetColor(ID_Color, baseCol);
                    mpb.SetFloat(ID_CoreAlpha, coreAlpha);
                    mpb.SetFloat(ID_InnerFrac, Mathf.Clamp01(inner / outer));
                    mpb.SetFloat(ID_Steps, steps);      // 0 = smooth gradient
                    sr.SetPropertyBlock(mpb);
                }
                break;

            case Mode.Gizmos:
                ClearChildren();
                if (sr) sr.enabled = false;
                break;
        }
    }

    void BuildChildren(int steps, Color baseCol, float inner, float outer)
    {
        ClearChildren();
        if (!ringSprite || steps <= 0) return;

        for (int i = 0; i < steps; i++)
        {
            float t0 = (float)i / steps;
            float radius = Mathf.Lerp(inner, outer, t0);
            float alpha = coreAlpha * (1f - t0);

            var go = new GameObject($"Ring_{i + 1}");
            go.transform.SetParent(transform, false);
            var r = go.AddComponent<SpriteRenderer>();
            r.sprite = ringSprite;
            r.sortingOrder = sortingOrder;
            r.color = new Color(baseCol.r, baseCol.g, baseCol.b, alpha);
            go.transform.localScale = Vector3.one * (2f * radius);
        }
    }

    void ClearChildren()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            var c = transform.GetChild(i).gameObject;
#if UNITY_EDITOR
            if (!Application.isPlaying) DestroyImmediate(c);
            else Destroy(c);
#else
            Destroy(c);
#endif
        }
    }

#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        if (mode != Mode.Gizmos) return;
        if (!lightZone && !darkZone) return;

        int steps = lightZone ? 3 : 5;
        float inner = lightZone ? Mathf.Max(0.0001f, lightZone.innerRadius)
                                : Mathf.Max(0.0001f, darkZone.innerRadius);
        float outer = inner + (lightZone ? Mathf.Max(0.0001f, lightZone.falloffDistance)
                                         : Mathf.Max(0.0001f, darkZone.falloffDistance));
        Color baseCol = lightZone ? lightColor : darkColor;

        for (int i = 0; i < steps; i++)
        {
            float t0 = (float)i / steps;
            float r = Mathf.Lerp(inner, outer, t0);
            var col = baseCol; col.a = coreAlpha * (1f - t0);
            Gizmos.color = col;
            Gizmos.DrawWireSphere(transform.position, r);
        }
    }
#endif
}
