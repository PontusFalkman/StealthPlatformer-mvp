// Scripts/Stealth/VisibilityField.cs
using UnityEngine;
using System.Collections.Generic;

public static class VisibilityField
{
    // Multiplicative blend with ambient as baseline LIGHT.
    // Returns [0,1] and snaps to ambient when outside all zones.
    public static float SampleAt(Vector2 worldPos, float ambientDarkness = 0.2f)
    {
        float ambientLight = Mathf.Clamp01(1f - ambientDarkness);

        // Lights: start at ambient, soft-add zones
        float lightVis = ambientLight;
        List<LightZone> lights = LightZone.All;
        for (int i = 0; i < lights.Count; i++)
        {
            var z = lights[i]; if (!z) continue;
            float c = Mathf.Clamp01(z.VisibilityAt(worldPos));
            lightVis = 1f - (1f - lightVis) * (1f - c);
            if (lightVis >= 0.999f) break;
        }

        // Darkness: strongest local patch (no ambient here)
        float darkLocal = 0f;
        var dzs = Object.FindObjectsByType<DarknessZone>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
        for (int i = 0; i < dzs.Length; i++)
        {
            var dz = dzs[i]; if (!dz) continue;
            darkLocal = Mathf.Max(darkLocal, Mathf.Clamp01(dz.DarknessAt(worldPos)));
            if (darkLocal >= 0.999f) break;
        }

        // Snap to ambient if outside both light and dark influence
        const float EPS = 0.01f;
        bool hadLight = lightVis > ambientLight + EPS;
        bool hadDark = darkLocal > EPS;
        if (!hadLight && !hadDark) return ambientLight;

        // Multiplicative attenuation
        return Mathf.Clamp01(lightVis * (1f - darkLocal));
    }
}
